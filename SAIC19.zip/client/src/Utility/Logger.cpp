#include "Logger.h"

Logger Logger::instance;