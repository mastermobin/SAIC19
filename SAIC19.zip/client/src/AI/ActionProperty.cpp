#include "ActionProperty.h"

void ActionProperty::addAffected(int heroId)
{
    affected.push_back(heroId);
}